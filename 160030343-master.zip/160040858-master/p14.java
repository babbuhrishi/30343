
class p14{
    public static void main(String[] ar){
         
             for(int i=1;i<=10;i++){
                  System.out.print(i+" ");
                       }
           }
}