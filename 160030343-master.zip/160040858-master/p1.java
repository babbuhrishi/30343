
class te{
    public static void main(String[] ar){
       
       System.out.println("Welcome"+" "+ar[0]);
}
}