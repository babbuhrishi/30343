
class p7{
    public static void main(String[] ar){
       char a='w';
   
          if(a>='a' && a<='z')
             
           System.out.print("Characters");
                       
            else if(a>= && a<=122)
                 System.out.print("Lower Case");
            else if(a>=0 && a<=9)
                    System.out.print("Number");
            else
               System.out.print("Special Case");
}
}