
class p4{
    public static void main(String[] ar){
       int a=Integer.parseInt(ar[0]);
       if(a>0)
         System.out.println("Positive");
       else if(a<0)
           System.out.println("Negative");
       else
           System.out.println("Zero");
}
}