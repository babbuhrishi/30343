import java.lang.*;
class p11{
   public static void main(String[] args){
   char a='w';
   if(a>='a' && a<='z')
      System.out.println(Character.toUpperCase(a));
   else
     System.out.println(Character.toLowerCase(a));
}}