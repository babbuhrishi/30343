
class p2{
    public static void main(String[] ar){
       int a=Integer.parseInt(a[0]);
       int b=Integer.parseInt(a[1]);
       System.out.println("The sum of %d and %d is"+(a+b));
}
}