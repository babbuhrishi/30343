
class p5{
    public static void main(String[] ar){
       try{
             for(int i=0;i<ar.length;i++){
           System.out.print(ar[i]+",");
                       }
             }catch(Exception e)
                     System.out.print("No Value");
}
}